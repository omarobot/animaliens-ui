import React from "react";
import CourseIntro from "../../components/CourseIntro/CourseIntro";

const Card3 = () => {
  return (
    <div className="css-n1ozge ">
      <CourseIntro />
    </div>
  );
};

export default Card3;
