import React from "react";
import CourseIntro from "../../components/CourseIntro/CourseIntro";

const Card2 = () => {
  return (
    <div className="css-n1ozge ">
      <CourseIntro />
    </div>
  );
};

export default Card2;
