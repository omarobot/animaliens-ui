import React from "react";
import CourseIntro from "../../components/CourseIntro/CourseIntro";

const Universecity = () => {
  return (
    <div className="css-n1ozge ">
      <CourseIntro />
    </div>
  );
};

export default Universecity;
