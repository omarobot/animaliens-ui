import React from "react";

const Card3 = () => {
  return (
    <div className="css-n1ozge no-margin">
      <h1
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          fontFamily: "Chakra Petch",
        }}
      >
        Individual Card
      </h1>
    </div>
  );
};

export default Card3;
