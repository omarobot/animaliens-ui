import * as wasm from "./cardano_serialization_lib_bg.wasm";
export * from "./cardano_serialization_lib_bg.js";