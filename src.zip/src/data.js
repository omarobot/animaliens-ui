const data = [{
        wallet: '9Uwf...qEVw'
    },
    {
        wallet: 'BNjh...cg1B'
    },
    {
        wallet: 'G6cQ...jJh6'
    },
    {
        wallet: '4Rq6...Sg2G'
    },
    {
        wallet: '9Uwf...qEVw'
    },
    {
        wallet: 'BNjh...cg1B'
    },
    {
        wallet: 'G6cQ...jJh6'
    },
    {
        wallet: '4Rq6...Sg2G'
    },
    {
        wallet: '9Uwf...qEVw'
    },
    {
        wallet: 'BNjh...cg1B'
    },
    {
        wallet: 'G6cQ...jJh6'
    },
    {
        wallet: '4Rq6...Sg2G'
    },
    {
        wallet: '9Uwf...qEVw'
    },
    {
        wallet: 'BNjh...cg1B'
    },
    {
        wallet: 'G6cQ...jJh6'
    },
    {
        wallet: '4Rq6...Sg2G'
    },
    {
        wallet: '9Uwf...qEVw'
    },
    {
        wallet: 'BNjh...cg1B'
    },
    {
        wallet: 'G6cQ...jJh6'
    },
    {
        wallet: '4Rq6...Sg2G'
    },
    {
        wallet: '9Uwf...qEVw'
    },
    {
        wallet: 'BNjh...cg1B'
    },
    {
        wallet: 'G6cQ...jJh6'
    },
    {
        wallet: '4Rq6...Sg2G'
    },
    {
        wallet: '9Uwf...qEVw'
    },
    {
        wallet: 'BNjh...cg1B'
    },
    {
        wallet: 'G6cQ...jJh6'
    },
    {
        wallet: '4Rq6...Sg2G'
    },
    {
        wallet: '9Uwf...qEVw'
    },
    {
        wallet: 'BNjh...cg1B'
    },
    {
        wallet: 'G6cQ...jJh6'
    },
    {
        wallet: '4Rq6...Sg2G'
    },
    {
        wallet: '9Uwf...qEVw'
    },
    {
        wallet: 'BNjh...cg1B'
    },
    {
        wallet: 'G6cQ...jJh6'
    },
    {
        wallet: '4Rq6...Sg2G'
    }
]

export default data;