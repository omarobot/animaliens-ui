import InfiniteGrid from "./InfiniteGrid";

export default InfiniteGrid;
