import StartButton from "./StartButton";

export { StartButton };
